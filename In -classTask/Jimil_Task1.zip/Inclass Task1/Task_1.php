<html>
<head>
	<title>Task 1</title>
	<style type="text/css">
		h1{
			text-align: center;
			color:red;
		}
	</style>
</head>
<body>

<h1> InClass Task 1 </h1>

<form method="POST" action="phptask1.php">

	Username: <input type="text" name="username" value="">
	<br> <br> <br>

	Password: <input type="text" name="password" value="">
	<br> <br> <br>
	
	<input type="submit" name="submit">
</form>

</body>
</html>
