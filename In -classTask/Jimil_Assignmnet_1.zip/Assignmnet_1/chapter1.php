<?php

$base = 10;
$height = 15;


$area = ($base * $height)/2;

$area = number_format($area, 2, '.', '');

echo "The area of the triangle is ".$area;
echo "<br>";
echo "<br>";

$MY_NAME = "Jimil Patel";

$MY_NAME = strtoupper($MY_NAME);

echo "My first name is <strong>".$MY_NAME."</strong>"
?>